//问题：url前后各加15s 蜜汁换视频问题 

//logs.js
const util = require('../../utils/util.js')
var cncontentArray = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""];
var jpcontentArray = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""];
var startTimeArray = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""];
var endTimeArray = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""];
var setColor = ["gray", "gray", "gray", "gray", "gray", "gray", "gray", "gray", "gray", "gray", "gray", "gray", "gray"]
const atime = 0;
var targetBool = [1,1,1,1,1,1,1,1,1,1,1];

//上一页获取
var sentence = "";
var targetWord = '素敵';
var titleTarget = '冬之樱04|冬の桜04';
var jpTarget = '';
var urlTarget = 'http://210.30.96.50:81/jtpo/Fuyu.no.Sakura.E04.720p.HDTV.x264.AAC-CHDTV.mp4?start=455&end=489';
var postmessage = '{"mediaID":151,"subtitleID":75292}';
//////////////



wx.getStorage({
  key: 'selectedItem',
  success: function (res) {
    //console.log(res.data.title)
    //console.log(res.data.kw)
    postmessage = res.data.idstr
    
     urlTarget=encodeURI(res.data.url)
    console.log(res.data.url)
    //有点问题放不出来
     targetWord=res.data.kw
    console.log(targetWord)
  },
})

Page({
  data: {
    //src是从上一个列表获取的
    src: urlTarget,
    logs: [],
    lengthTotal:0,
    color0:setColor[0],
    color1: setColor[1],
    color2: setColor[2],
    color3: setColor[3],
    color4: setColor[4],
    color5: setColor[5],
    color6: setColor[6],
    color7: setColor[7],
    color8: setColor[8],
    color9: setColor[9],
    color10: setColor[10],
    color11: setColor[11],
    text0:'null',
    text1: 'null',
    text2: 'null',
    text3: '',
    text4: '',
    text5: '',
    text6: '',
    text7: '',
    text8: '',
    text9: '',
    text10: '',
    text11: '',
    atext0:'',
    atext5:'',
    targettext:'nulltext',
    color_keyword:'red',
    //获取
    target: targetWord,
    title: titleTarget,
    show: false
    //////////////

  },
  videoErrorCallback: function (e) {
    console.log('video is ERROR!')
  },
　
　onReady:function(){
   console.log(urlTarget)
   wx.getStorage({
     key: 'selectedItem',
     success: function (res) {

       //console.log(res)
       postmessage = res.data.idstr
       targetWord = res.data.kw
       titleTarget = res.data.title
       urlTarget = encodeURI(res.data.url)
      //  this.setData({
      //    target:targetWord,
      //  })

     },
   })
},
onShow: function () {


var targetIndex = 0;
    var page = this;
    var req_obj = {
      url: 'https://www.japanesecorpus.com.cn/api/fv/getsubtitlelist',
      data: postmessage,
      method: 'POST',
      success: function (resp) {
        console.log(resp.data.data);
        for (var i = 0; i < resp.data.data.length; i++) {
          cncontentArray[i] = resp.data.data[i].cncontent;
          jpcontentArray[i] = resp.data.data[i].jpcontent;
          startTimeArray[i] = resp.data.data[i].startTime;
          endTimeArray[i] = resp.data.data[i].endTime;
        }
      
        page.setData({
        　target:targetWord,
          lengthTotal:resp.data.data.length,
  　　　　 title:titleTarget,
          src:urlTarget,
          // text0: jpcontentArray[0].split(targetWord)[0],
          // target: targetWord,
          // atext0: jpcontentArray[0].split(targetWord)[1],
          // text1: jpcontentArray[1].split(targetWord)[0],
          // target: targetWord,
          // atext1: jpcontentArray[1].split(targetWord)[1],
          // text2: jpcontentArray[2].split(targetWord)[0],
          // atext2: jpcontentArray[2].split(targetWord)[1],
          // text3: jpcontentArray[3].split(targetWord)[0],
          // atext3: jpcontentArray[3].split(targetWord)[1],
          // text4: jpcontentArray[4].split(targetWord)[0],
          // atext4: jpcontentArray[4].split(targetWord)[1],

         

          // text5: jpcontentArray[5].split(targetWord)[0],
          // atext5: jpcontentArray[5].split(targetWord)[1],

          // text6: jpcontentArray[6].split(targetWord)[0],
          // atext6: jpcontentArray[6].split(targetWord)[1],
          // text7: jpcontentArray[7].split(targetWord)[0],
          // atext7: jpcontentArray[7].split(targetWord)[1],
          // text8: jpcontentArray[8].split(targetWord)[0],
          // atext8: jpcontentArray[8].split(targetWord)[1],
          // text9: jpcontentArray[9].split(targetWord)[0],
          // atext9: jpcontentArray[9].split(targetWord)[1],
          // text10: jpcontentArray[10].split(targetWord)[0],
          // atext10: jpcontentArray[10].split(targetWord)[1],

          text0: jpcontentArray[0],
          text1: jpcontentArray[1],
          text2: jpcontentArray[2],
          text3: jpcontentArray[3],
          text4: jpcontentArray[4],
          text5: jpcontentArray[5],
          text6: jpcontentArray[6],
          text7: jpcontentArray[7],
          text8: jpcontentArray[8],
          text9: jpcontentArray[9],
          text10: jpcontentArray[10],


  



           text0c: cncontentArray[0],
          text1c: cncontentArray[1],
          text2c: cncontentArray[2],
          text3c: cncontentArray[3],
          text4c: cncontentArray[4],
          text5c: cncontentArray[5],
          text6c: cncontentArray[6],
          text7c: cncontentArray[7],
          text8c: cncontentArray[8],
          text9c: cncontentArray[9],
          text10c: cncontentArray[10],


          condition0:0,
          condition1: 0,
          condition2: 0,
          condition3: 0,
          condition4: 0,
          condition5:0,
          condition6: 0,
          condition7: 0,
          condition8: 0,
          condition9: 0,
          condition10: 0,
          //condition11: 0,
        })
        for (var i = 0; i < resp.data.data.length; i++) {
          console.log(targetWord)
          if (resp.data.data[i].jpcontent==resp.data.data[i].jpcontent.split(targetWord)[0]){
             targetBool[i] = 0;
          }
          if (resp.data.data[i].jpcontent === jpTarget){
            targetIndex = i;
          }
        }
        page.setData({
          condition0:targetBool[0],
          condition1: targetBool[1],
          condition2: targetBool[2],
          condition3: targetBool[3],
          condition4: targetBool[4],
          condition5:targetBool[5],
          condition6: targetBool[6],
          condition7: targetBool[7],
          condition8: targetBool[8],
          condition9: targetBool[9],
          condition10: targetBool[10],
         // condition11: targetBool[11],
        })
        //setColor[targetIndex] = 'red';

      },
      fail: function (resp) {
        console.log(resp.data);
        console.log(resp.statusCode);
      }
    }
    wx.request(req_obj);


    this.videoContext = wx.createVideoContext('myVideo')
    this.setData({
      logs: (wx.getStorageSync('logs') || []).map(log => {
        return util.formatTime(new Date(log))
      })
    })
  },




onLoad:function(){
  setTimeout(function () {
    var app = getApp();
    if (!app.globalData.isFresh) {
      app.globalData.isFresh = true
      console.log("this come from logs,if you see this sentence the page have loaded the second times:"+app.globalData.isFresh)
      wx.redirectTo({
        url: '../logs/logs',
      })
    }
    //要延时执行的代码
  }, 100) //延迟时间 这里是1秒

},

fresh:function(){
  console.log("ok!")
  wx.redirectTo({
    url: '../logs/logs',
  })
},

  CheckTime: function (e) {
    //console.log(e.detail.currentTime);
    if (e.detail.currentTime >= 0 && e.detail.currentTime < startTimeArray[0] - startTimeArray[0] - atime){
      this.setData({
        color0: setColor[0],
        color1: setColor[1],
        color2: setColor[2],
        color3: setColor[3],
        color4: setColor[4],
        color5: setColor[5],
        color6: setColor[6],
        color7: setColor[7],
        color8: setColor[8],
        color9: setColor[9],
        color10: setColor[10],
        color11: setColor[11],
      })
    }
    else if (e.detail.currentTime > startTimeArray[0] - startTimeArray[0] - atime&& e.detail.currentTime < endTimeArray[0] - startTimeArray[0]-atime) {
      this.setData({
        color0: 'blue',
        color1: setColor[1],
        color2: setColor[2],
        color3: setColor[3],
        color4: setColor[4],
        color5: setColor[5],
        color6: setColor[6],
        color7: setColor[7],
        color8: setColor[8],
        color9: setColor[9],
        color10: setColor[10],
        color11: setColor[11],
      })
    } else if (e.detail.currentTime >= startTimeArray[1] - startTimeArray[0] - atime && e.detail.currentTime < endTimeArray[1] - startTimeArray[0] - atime) {
      this.setData({
        color0: setColor[0],
        color1: 'blue',
        color2: setColor[2],
        color3: setColor[3],
        color4: setColor[4],
        color5: setColor[5],
        color6: setColor[6],
        color7: setColor[7],
        color8: setColor[8],
        color9: setColor[9],
        color10: setColor[10],
        color11: setColor[11],
      })
    } else if (e.detail.currentTime >= startTimeArray[2] - startTimeArray[0] - atime && e.detail.currentTime < endTimeArray[2] - startTimeArray[0] - atime) {
      this.setData({
        color0: setColor[0],
        color1: setColor[1],
        color2: 'blue',
        color3: setColor[3],
        color4: setColor[4],
        color5: setColor[5],
        color6: setColor[6],
        color7: setColor[7],
        color8: setColor[8],
        color9: setColor[9],
        color10: setColor[10],
        color11: setColor[11],
      })
    } else if (e.detail.currentTime >= startTimeArray[3] - startTimeArray[0] - atime && e.detail.currentTime < endTimeArray[3] - startTimeArray[0] - atime) {
      this.setData({
        color0: setColor[0],
        color1: setColor[1],
        color2: setColor[2],
        color3: 'blue',
        color4: setColor[4],
        color5: setColor[5],
        color6: setColor[6],
        color7: setColor[7],
        color8: setColor[8],
        color9: setColor[9],
        color10: setColor[10],
        color11: setColor[11],
      })
    } else if (e.detail.currentTime >= startTimeArray[4] - startTimeArray[0] - atime && e.detail.currentTime < endTimeArray[4] - startTimeArray[0] - atime) {
      this.setData({
        color0: setColor[0],
        color1: setColor[1],
        color2: setColor[2],
        color3: setColor[3],
        color4: 'blue',
        color5: setColor[5],
        color6: setColor[6],
        color7: setColor[7],
        color8: setColor[8],
        color9: setColor[9],
        color10: setColor[10],
        color11: setColor[11],
      })
    } else if (e.detail.currentTime >= startTimeArray[5] - startTimeArray[0] - atime && e.detail.currentTime < endTimeArray[5] - startTimeArray[0] - atime) {
      this.setData({
        color0: setColor[0],
        color1: setColor[1],
        color2: setColor[2],
        color3: setColor[3],
        color4: setColor[4],
        color5: 'blue',
        color6: setColor[6],
        color7: setColor[7],
        color8: setColor[8],
        color9: setColor[9],
        color10: setColor[10],
        color11: setColor[11],
      })
    } else if (e.detail.currentTime >= startTimeArray[6] - startTimeArray[0] - atime && e.detail.currentTime < endTimeArray[6] - startTimeArray[0] - atime) {
      this.setData({
        color0: setColor[0],
        color1: setColor[1],
        color2: setColor[2],
        color3: setColor[3],
        color4: setColor[4],
        color5: setColor[5],
        color6: 'blue',
        color7: setColor[7],
        color8: setColor[8],
        color9: setColor[9],
        color10: setColor[10],
        color11: setColor[11],
      })
    } else if (e.detail.currentTime >= startTimeArray[7] - startTimeArray[0] - atime && e.detail.currentTime < endTimeArray[7] - startTimeArray[0] - atime){
      this.setData({
        color0: setColor[0],
        color1: setColor[1],
        color2: setColor[2],
        color3: setColor[3],
        color4: setColor[4],
        color5: setColor[5],
        color6: setColor[6],
        color7: 'blue',
        color8: setColor[8],
        color9: setColor[9],
        color10: setColor[10],
        color11: setColor[11],
      })
    } else if (e.detail.currentTime >= startTimeArray[8] - startTimeArray[0] - atime && e.detail.currentTime < endTimeArray[8] - startTimeArray[0] - atime){
      this.setData({
        color0: setColor[0],
        color1: setColor[1],
        color2: setColor[2],
        color3: setColor[3],
        color4: setColor[4],
        color5: setColor[5],
        color6: setColor[6],
        color7: setColor[7],
        color8: 'blue',
        color9: setColor[9],
        color10: setColor[10],
        color11: setColor[11],
      })
    } else if (e.detail.currentTime >= startTimeArray[9] - startTimeArray[0] - atime && e.detail.currentTime < endTimeArray[9] - startTimeArray[0] - atime) {
      this.setData({
        color0: setColor[0],
        color1: setColor[1],
        color2: setColor[2],
        color3: setColor[3],
        color4: setColor[4],
        color5: setColor[5],
        color6: setColor[6],
        color7: setColor[7],
        color8: setColor[8],
        color9: 'blue',
        color10: setColor[10],
        color11: setColor[11],
      })
    } else if (e.detail.currentTime >= startTimeArray[10] - startTimeArray[0] - atime && e.detail.currentTime < endTimeArray[10] - startTimeArray[0] - atime) {
      this.setData({
       color0: setColor[0],
        color1: setColor[1],
        color2: setColor[2],
        color3: setColor[3],
        color4: setColor[4],
        color5: setColor[5],
        color6: setColor[6],
        color7: setColor[7],
        color8: setColor[8],
        color9: setColor[9],
        color10: 'blue',
        color11: setColor[11],
      })
    } 


  }
  ,
  // 只留一个
  lyrics_list_content0: function () {

      this.setData({
      color0: 'blue',
      color1: setColor[1],
      color2: setColor[2],
      color3: setColor[3],
      color4: setColor[4],
      color5: setColor[5],
      color6: setColor[6],
      color7: setColor[7],
      color8: setColor[8],
      color9: setColor[9],
      color10: setColor[9],
      color11: setColor[11],
      }),
      this.videoContext.seek(startTimeArray[0] - startTimeArray[0] - atime);
  },
  lyrics_list_content1: function () {

      this.setData({
      color0: setColor[0],
      color1: 'blue',
      color2: setColor[2],
      color3: setColor[3],
      color4: setColor[4],
      color5: setColor[5],
      color6: setColor[6],
      color7: setColor[7],
      color8: setColor[8],
      color9: setColor[9],
      color10: setColor[9],
      color11: setColor[11],
      }),
      this.videoContext.seek(startTimeArray[1] - startTimeArray[0] - atime);
  },
  lyrics_list_content2: function () {

      this.setData({
      color0: setColor[0],
      color1: setColor[1],
      color2: 'blue',
      color3: setColor[3],
      color4: setColor[4],
      color5: setColor[5],
      color6: setColor[6],
      color7: setColor[7],
      color8: setColor[8],
      color9: setColor[9],
      color10: setColor[9],
      color11: setColor[11],
      }),
      this.videoContext.seek(startTimeArray[2] - startTimeArray[0] - atime);
  }, 
  lyrics_list_content3: function () {

      this.setData({
      color0: setColor[0],
      color1: setColor[1],
      color2: setColor[2],
      color3: 'blue',
      color4: setColor[4],
      color5: setColor[5],
      color6: setColor[6],
      color7: setColor[7],
      color8: setColor[8],
      color9: setColor[9],
      color10: setColor[9],
      color11: setColor[11],
      }),
      this.videoContext.seek(startTimeArray[3] - startTimeArray[0] - atime);
  }, 
  lyrics_list_content4: function () {

      this.setData({
      color0: setColor[0],
      color1: setColor[1],
      color2: setColor[2],
      color3: setColor[3],
      color4: 'blue',
      color5: setColor[5],
      color6: setColor[6],
      color7: setColor[7],
      color8: setColor[8],
      color9: setColor[9],
      color10: setColor[9],
      color11: setColor[11],
      }),
      this.videoContext.seek(startTimeArray[4] - startTimeArray[0] - atime);
  }, 
  lyrics_list_content5: function () {

      this.setData({
      color0: setColor[0],
      color1: setColor[1],
      color2: setColor[2],
      color3: setColor[3],
      color4: setColor[4],
      color5: 'blue',
      color6: setColor[6],
      color7: setColor[7],
      color8: setColor[8],
      color9: setColor[9],
      color10: setColor[9],
      color11: setColor[11],
      }),
      this.videoContext.seek(startTimeArray[5] - startTimeArray[0] - atime);
  },
  lyrics_list_content6: function () {

      this.setData({
      color0: setColor[0],
      color1: setColor[1],
      color2: setColor[2],
      color3: setColor[3],
      color4: setColor[4],
      color5: setColor[5],
      color6: 'blue',
      color7: setColor[7],
      color8: setColor[8],
      color9: setColor[9],
      color10: setColor[9],
      color11: setColor[11],
      }),
      this.videoContext.seek(startTimeArray[6] - startTimeArray[0] - atime);
  },
  lyrics_list_content7: function () {

      this.setData({
      color0: setColor[0],
      color1: setColor[1],
      color2: setColor[2],
      color3: setColor[3],
      color4: setColor[4],
      color5: setColor[5],
      color6: setColor[6],
      color7: 'blue',
      color8: setColor[8],
      color9: setColor[9],
      color10: setColor[9],
      color11: setColor[11],
      }),
      this.videoContext.seek(startTimeArray[7] - startTimeArray[0] - atime);
  },
  lyrics_list_content8: function () {

      this.setData({
      color0: setColor[0],
      color1: setColor[1],
      color2: setColor[2],
      color3: setColor[3],
      color4: setColor[4],
      color5: setColor[5],
      color6: setColor[6],
      color7: setColor[7],
      color8: 'blue',
      color9: setColor[9],
      color10: setColor[9],
      color11: setColor[11],
      }),
      this.videoContext.seek(startTimeArray[8] - startTimeArray[0] - atime);
  },
  lyrics_list_content9: function () {

      this.setData({
      color0: setColor[0],
      color1: setColor[1],
      color2: setColor[2],
      color3: setColor[3],
      color4: setColor[4],
      color5: setColor[5],
      color6: setColor[6],
      color7: setColor[7],
      color8: setColor[8],
      color9: 'blue',
      color10: setColor[9],
      color11: setColor[11],
      }),
      this.videoContext.seek(startTimeArray[9] - startTimeArray[0] - atime);
  },
  lyrics_list_content10: function () {

      this.setData({
      color0: setColor[0],
      color1: setColor[1],
      color2: setColor[2],
      color3: setColor[3],
      color4: setColor[4],
      color5: setColor[5],
      color6: setColor[6],
      color7: setColor[7],
      color8: setColor[8],
      color9: setColor[9],
      color10: 'blue',
      color11: setColor[11],
      }),
      this.videoContext.seek(startTimeArray[10] - startTimeArray[0] - atime);
  },
  

})
