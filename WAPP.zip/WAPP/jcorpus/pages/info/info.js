//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    // nickname:"孙力壮#" ,
    // grade:"大二#",
    // student_id:"201693057#",
    // school:"大连理工大学#"
  },
  //事件处理函数
  go_to_home: function () {
    wx.cloud.callFunction({
      name: 'get_user',
      complete: res => {
        console.log(res.result.data)
        if (res.result.data.length == 0) { // no data --> new user
          wx.navigateTo({
            url: '../register/register'
          })
        } else {
          wx.navigateTo({
            url: '../search/search'
          })
        }
      }
    })

    // // below is just to adjustment need to be changed when publish
    //       wx.navigateTo({
    //         url: '../register/register'
    //       })
  },
  onLoad: function () {
    var that = this
    wx.cloud.callFunction({
      name: 'get_user',
      complete: res => {
        console.log(res.result.data)
        //console.log(that.data.grade_list)
        var data_ = res.result.data[0]

        that.setData({
          nickname: data_.nickname,
          grade: data_.grade,
          student_id: data_.student_id,
          school: data_.school
        })
      }
    })
    // this.setData({
    //   nickname: "孙力壮#",
    //   grade: "大二#",
    //   student_id: "201693057#",
    //   school: "大连理工大学#"
    // })
    



    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse) {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  getUserInfo: function (e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  }
})
