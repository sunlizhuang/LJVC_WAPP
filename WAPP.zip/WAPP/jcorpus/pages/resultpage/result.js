// miniprogram/pages/resultpage/result.js
var prom = require("./prom.js")

var app = getApp()
var sentence = ""
var nickname = ""

Page({

  /**
   * 页面的初始数据
   */
  data: {
    moved: false,
    pagecount: 0,
    curWord: "",
    keyword: "",
    itemcount: 0,
    showModal: false,
    hidden: true,
    currPitemcount: 0,
    pageslist: [],
    pindex: 0,
    results: [

    ],
    offset: 0
  },
  bindPickerChange(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      pindex: e.detail.value
    })
  },
  onReachBottom: function (e) {
    console.log(1)
  },
  onTouchmove: function () {
    this.setData({
      moved: true,
    })
  },
  inputWord: function (e) {
    this.setData({
      curWord: e.detail.value
    })
  },
  onItemClick: function (e) {
    this.setData({
      hidden: !this.data.hidden
    });




    console.log("点击，当前页面信息", this.data.results)
    if (this.data.moved) {
      this.setData({
        moved: false,
      })
      return
    }
    var id = e.currentTarget.id
    console.log("!!!!!!!!!!!!!!!!!!!!!!1")
    console.log(e, this.data.offset)
    console.log(id - this.data.offset)
    console.log(this.data.results[id - this.data.offset])
    wx.setStorage({
      key: 'selectedItem',
      data: this.data.results[id - this.data.offset],
    })


    wx.cloud.callFunction({

      name: 'save_SearchRecords',
      data: {
        keyword: this.data.keyword,
      },
    })

    setTimeout(function () {
      //要延时执行的代码
    }, 1000) //延迟时间 这里是1秒
    prom.wxPromisify(wx.navigateTo({
      url: '../logs/logs',
    }))
    // wx.navigateTo({
    //   url: '../logs/logs',
    // })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      curPage: 1
    })
    this.setData({
      hidden: true
    });
    var p = this;
    wx.getStorage({
      key: 'curWord',
      success: function (res) {
        p.setData({
          curWord: res.data,
          keyword: res.data
        })
        console.log(res)
      },
    })
    wx.getStorage({
      key: 'totlePage',
      success: function (res) {
        p.setData({
          totlePage: res.data
        })
        console.log(res)
      },
    })
    wx.getStorage({

      key: 'results',
      success: function (res) {

        p.addAPage(res.data)
      },
    })



  },

  addAPage(e) {
    var pc = this.data.pagecount;
    var p = this;
    console.log(e)
    this.setData({
      currPitemcount: e.length,
      offset: p.data.offset + p.data.currPitemcount
    })
    console.log('重设page信息', this.data.offset, p.data.offset, p.data.currPitemcount)

    this.setData({
      pageslist: [],
      results: []
    })


    var plist = this.data.pageslist
    for (var i = 0; i < this.data.totlePage; i++) {

      p.data.pageslist.push((i + 1).toString())

    }
    this.setData({
      pageslist: p.data.pageslist
    })
    this.setData({
      pagecount: this.pagecount + 1
    })

    this.setData({
      results: this.data.results
    })

    p.results = []
    for (var i in e) {

      var title = e[i].title;
      var content = e[i].subtitleList[0].jpcontent;
      /////////////////////////////////////////////////////////////////////////////
      var time_start = e[i].subtitleList[0].startTime - 15;
      /////////////////////////////////////////////////////////////////////////////
      var subtitleID = e[i].subtitleList[0].subtitleID;
      var mediaID = e[i].subtitleList[0].mediaID;
      var idstr = "{\"mediaID\":" + mediaID.toString() + ",\"subtitleID\":" + subtitleID.toString() + "}"
      /////////////////////////////////////////////////////////////////////////////
      var time_end = e[i].subtitleList[0].endTime + 15;
      /////////////////////////////////////////////////////////////////////////////
      var t_s_minute = Math.floor(time_start / 60);
      var t_e_minute = Math.floor(time_end / 60);
      var t_s_s = (time_start - 60 * t_s_minute).toFixed(0);
      var t_e_s = (time_end - 60 * t_e_minute).toFixed(0);
      var str_tstart = t_s_minute.toString() + ":" + (t_s_s < 10 ? "0" + t_s_s.toString() : t_s_s.toString())
      var str_tend = t_e_minute.toString() + ":" + (t_e_s < 10 ? "0" + t_e_s.toString() : t_e_s.toString())

      var timestr = str_tstart + "->" + str_tend;
      var totleS = e[i].subtitleList.length;
      var url = e[i].url;
      url = url + "?start=" + time_start.toString() + "&end=" + time_end.toString()
      var kw = p.data.keyword
      // console.log({
      //  title,content,url,timestr,totleS
      //})
      var id = p.data.itemcount;
      p.setData({
        itemcount: id + 1
      })
      p.data.results.push({
        id, title, content, url, timestr, totleS, kw, idstr
      })
    }

    console.log(p.data.results)
    this.setData({
      results: p.data.results
    })

    console.log(this.data.results)
    wx.removeStorage({
      key: 'results',
      success: function (res) { },
    })
  },
  addItem: function (e) {
    var obj = e.time;
    var title = e.title;
    var c = e.context;
    var hyk = e.honnyaku;
    var t = e.time;
    var sourceaddress = e.source;
    this.data.sentence.push({ title: title, context: c, honnyaku: hyk, time: t, source: "111" })
    console.log(this.data.sentence)
    this.setData({
      sentence: this.data.sentence
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.setData({
      hidden: true
    });
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var app = getApp();
    if (app.globalData.isFresh) {
      app.globalData.isFresh = false
    }
    console.log(app.globalData.isFresh)
    　　　　this.setData({
      hidden: true
    });
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },


  onNextPageClick: function () {
    //console.log("nextpage")

    var p = this

    if (p.data.curPage + 1 > p.data.totlePage) return;
    wx.request({
      url: 'https://www.japanesecorpus.com.cn/api/fv/getvideolist',
      data: {
        keyword: p.data.keyword,
        page: p.data.curPage + 1
      },
      method: "POST",
      success(res) {
        p.setData({
          results: [],
        })
        wx.removeStorage({
          key: 'results',
          success: function (res) { },
        })
        p.addAPage(res.data.data.list)
        p.setData({
          curPage: (p.data.curPage + 1)

        })
      }
    })
  },
  Sure_click: function () {
    var p = this

    var to = parseInt(p.data.pageslist[p.data.pindex])
    wx.request({
      url: 'https://www.japanesecorpus.com.cn/api/fv/getvideolist',
      data: {
        keyword: p.data.keyword,
        page: to
      },
      method: "POST",
      success(res) {
        p.setData({
          results: [],
        })
        wx.removeStorage({
          key: 'results',
          success: function (res) { },
        })

        p.addAPage(res.data.data.list)
        p.setData({
          showModal: false
        })

        p.setData({
          curPage: to
        })
      }
    })
  },
  onLastPageClick: function () {
    console.log("lastpage")

    var p = this

    if (p.data.curPage - 1 <= 0) return;
    wx.request({
      url: 'https://www.japanesecorpus.com.cn/api/fv/getvideolist',
      data: {
        keyword: p.data.keyword,
        page: p.data.curPage - 1
      },
      method: "POST",
      success(res) {
        p.setData({
          results: [],
        })
        wx.removeStorage({
          key: 'results',
          success: function (res) { },
        })

        p.addAPage(res.data.data.list)
        p.setData({
          curPage: (p.data.curPage - 1)
        })
      }
    })
  },

  modal_click_Hidden: function () {
    this.setData({
      showModal: false,
    })
  },
  onPageLabelTouched() {
    console.log(this.data.pageslist)
    this.setData({
      showModal: true
    })

  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },



  onSearch_click: function () {
    var k = this.data.curWord
    if (k == "") return
    var p = this
    wx.request({
      url: 'https://www.japanesecorpus.com.cn/api/fv/getvideolist',
      data: {
        keyword: k,
        page: 1
      },
      method: "POST",
      success(res) {
        p.setData({
          results: [],
          keyword: k
        })
        wx.removeStorage({
          key: 'results',
          success: function (res) { },
        })

        p.addAPage(res.data.data.list)
      }
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})