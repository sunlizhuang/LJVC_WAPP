// pages/register/register.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    grade_list: ['初中', '高中', '大一', '大二', '大三', '大四', '大五', '研一', '研二', '研三']
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },
  bindPickerChange(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index: e.detail.value
    })
  },
  do_register: function(e){
    wx.cloud.callFunction({
      name: 'do_register',
      data: {
        nickname: e.detail.value.nickname,
        school: e.detail.value.school,
        grade: this.data.grade_list[e.detail.value.grade],
        student_id: e.detail.value.student_id
      },
      complete: res => {
        // console.log('callFunction test result: ', res)
        wx.navigateTo({
          url: '../search/search'
        })
      },
    })

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})