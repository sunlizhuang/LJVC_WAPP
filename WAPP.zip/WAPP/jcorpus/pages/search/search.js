// miniprogram/pages/search/search.js

//var template = require('../../template/template.js');
var timestamp = Date.parse(new Date());
timestamp = timestamp / 1000; 
Page({

  /**
   * 页面的初始数据
   */
  data: {
    keyword:"",
    hidden:true
  },

  /**
   * 生命周期函数--监听页面加载
   */
  inputkeyword:function(e){
    this.setData({
      keyword: e.detail.value
    })
  },
welcome:function(){
console.log("个人信息页面")
 
      wx.navigateTo({
        url: '../info/info',
      })
},
  hot1:function(e){
    this.setData({
      hidden:!this.data.hidden
    });
    var k = "愛"
    wx.request({
      url: 'https://www.japanesecorpus.com.cn/api/fv/getvideolist',
      data: {
        keyword: k,
        page: 1
      },
      method: "POST",
      success(res) {

        wx.removeStorage({
          key: 'results',
          success: function (res) { },
        })


        wx.setStorage({
          key: 'results',
          data: res.data.data.list,
        })
        wx.setStorage({
          key: 'curWord',
          data: k,
        })
        wx.getStorage({
          key: 'results',
          success: function (res) {
            wx.navigateTo({
              url: '../resultpage/result',
            })
          },
        })
      }
    })
  },
  hot2: function (e) {
    this.setData({
      hidden: !this.data.hidden
    });
    var k = "素敵"
    wx.request({
      url: 'https://www.japanesecorpus.com.cn/api/fv/getvideolist',
      data: {
        keyword: k,
        page: 1
      },
      method: "POST",
      success(res) {

        wx.removeStorage({
          key: 'results',
          success: function (res) { },
        })


        wx.setStorage({
          key: 'results',
          data: res.data.data.list,
        })
        wx.setStorage({
          key: 'curWord',
          data: k,
        })
        wx.getStorage({
          key: 'results',
          success: function (res) {
            wx.navigateTo({
              url: '../resultpage/result',
            })
          },
        })
      }
    })
  },
  hot3: function (e) {
    this.setData({
      hidden: !this.data.hidden
    });
    var k = "好き"
    wx.request({
      url: 'https://www.japanesecorpus.com.cn/api/fv/getvideolist',
      data: {
        keyword: k,
        page: 1
      },
      method: "POST",
      success(res) {

        wx.removeStorage({
          key: 'results',
          success: function (res) { },
        })


        wx.setStorage({
          key: 'results',
          data: res.data.data.list,
        })
        wx.setStorage({
          key: 'curWord',
          data: k,
        })
        wx.getStorage({
          key: 'results',
          success: function (res) {
            wx.navigateTo({
              url: '../resultpage/result',
            })
          },
        })
      }
    })
  },
  hot4: function (e) {
    this.setData({
      hidden: !this.data.hidden
    });
    var k = "食べる"
    wx.request({
      url: 'https://www.japanesecorpus.com.cn/api/fv/getvideolist',
      data: {
        keyword: k,
        page: 1
      },
      method: "POST",
      success(res) {

        wx.removeStorage({
          key: 'results',
          success: function (res) { },
        })


        wx.setStorage({
          key: 'results',
          data: res.data.data.list,
        })
        wx.setStorage({
          key: 'curWord',
          data: k,
        })
        wx.getStorage({
          key: 'results',
          success: function (res) {
            wx.navigateTo({
              url: '../resultpage/result',
            })
          },
        })
      }
    })
  },
  hot5: function (e) {
    this.setData({
      hidden: !this.data.hidden
    });
    var k = "行き"
    wx.request({
      url: 'https://www.japanesecorpus.com.cn/api/fv/getvideolist',
      data: {
        keyword: k,
        page: 1
      },
      method: "POST",
      success(res) {

        wx.removeStorage({
          key: 'results',
          success: function (res) { },
        })


        wx.setStorage({
          key: 'results',
          data: res.data.data.list,
        })
        wx.setStorage({
          key: 'curWord',
          data: k,
        })
        wx.getStorage({
          key: 'results',
          success: function (res) {
            wx.navigateTo({
              url: '../resultpage/result',
            })
          },
        })
      }
    })
  },
  onLoad: function (options) {
    //template.tabbar("tabBar", 0, this)
    var that = this
    wx.cloud.callFunction({
      name: 'get_user',
      complete: res => {
        console.log(res.result.data)
        //console.log(that.data.grade_list)
        var data_ = res.result.data[0]

        that.setData({
          nickname: data_.nickname,
          grade: data_.grade,
          student_id: data_.student_id,
          school: data_.school
        })
      }
    })
    if (this.data.canIUse) {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },

  onSearch_click:function(){
    this.setData({
      hidden: !this.data.hidden
    });
    //get
    //http://www.japanesecorpus.com.cn/api/fv/getvideolist
    var k=this.data.keyword
    if( k=="") return

    wx.request({
      url: 'https://www.japanesecorpus.com.cn/api/fv/getvideolist',
      data:{
        keyword: k,
        page:1
      },
      method:"POST",
      success(res){
        console.log(res)
        wx.removeStorage({
          key: 'results',
          success: function(res) {},
        })


        wx.setStorage({
          key: 'results',
          data: res.data.data.list,
        })
        wx.setStorage({
          key: 'totlePage',
          data: res.data.data.totalPage
        })
        wx.setStorage({
          key: 'curWord',
          data: k,
        })
        wx.getStorage({
          key: 'results',
          success: function(res) {
           wx.navigateTo({
             url: '../resultpage/result',
               })
          },
        })
      }
    })




    //wx.navigateTo({
   //   url: '../resultpage/result',
    //})
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.setData({
      hidden: true
    });
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      hidden: true
    });
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    this.setData({
      hidden: true
    });
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    this.setData({
      hidden: true
    });
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.setData({
      hidden: true
    });
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    this.setData({
      hidden: true
    });
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})