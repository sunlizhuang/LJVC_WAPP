// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()
const db = cloud.database()
const _ = db.command
// 云函数入口函数

exports.main = async (event, context) => new Promise((resolve, reject) => {
  const wxContext = cloud.getWXContext()
  var status
  var data_ = event


      //console.log(nickname),
  db.collection('SearchRecords').add({
    data: {
      openid: wxContext.OPENID,
      keyword: data_.keyword,
      example:data_.example,
      time: db.serverDate(),
    }
  }).then(res => {
    resolve(res)
  }).catch(console.error)
})
