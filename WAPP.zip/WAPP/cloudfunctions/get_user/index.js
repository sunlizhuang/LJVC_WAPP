// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()
const db = cloud.database()
const _ = db.command
// 云函数入口函数

exports.main = async (event, context) => new Promise((resolve, reject) => {
  const wxContext = cloud.getWXContext()
  var status
  db.collection('user').where({
    openid: wxContext.OPENID
  }).get()
  .then(res=> {
    resolve(res) // resolve is to send result when 异步 in promise mode
  }
  )

  // return wxContext.OPENID
 
})