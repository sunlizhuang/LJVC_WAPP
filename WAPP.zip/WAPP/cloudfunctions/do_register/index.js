// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()
const db = cloud.database()
const _ = db.command
// 云函数入口函数

exports.main = async (event, context) => new Promise((resolve, reject) => {
  const wxContext = cloud.getWXContext()
  var status
  var data_ = event
  db.collection('user').add({
      data: {
        openid: wxContext.OPENID,
        nickname: data_.nickname,
        grade: data_.grade,
        school: data_.school,
        student_id: data_.student_id
      }
    }).then(res => {
      resolve(res)
    }).catch(console.error)
})
